"""Independent numeric/receipt audit of this frozen 96-JVM comparison; timings are descriptive."""
import csv,json,math,statistics,sys,itertools,hashlib
from pathlib import Path
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent
raw=root/'performance'; entries={}; cells=list(itertools.product([0,1],[2,4],['init1','init3','flash'],[5,15]));cells=[x for x in cells if x[3]==5 or x[2]=='flash']
maxima={'balance':0.,'normalization':0.,'log_fugacity':0.,'matched_state_absolute_difference':0.}; vector_rows=0
for profile,rule,scenario,size in cells:
 for fork in range(2):
  reference=None
  for arm in ('base','candidate','control'):
   name=f'p{profile}-r{rule}-{scenario}-n{size}-f{fork}-{arm}';p=raw/(name+'.csv'); rows=list(csv.DictReader(p.open()));states=list(csv.DictReader((raw/(name+'.csv.states.csv')).open()));assert len(rows)==10 and {int(x['round']) for x in rows}==set(range(10));vector_rows+=len(states);vectors={}
   for row in rows:
    assert int(row['profile'])==profile and int(row['rule'])==rule and row['scenario']==scenario and int(row['components'])==size
    rr=[x for x in states if int(x['round'])==int(row['round'])];phase_ids=sorted({int(x['phase']) for x in rr});assert phase_ids==list(range(len(phase_ids)))
    phase_map={i:[x for x in rr if int(x['phase'])==i] for i in phase_ids};species={x['component'] for x in phase_map[0]};assert len(species)==size
    beta_sum=0.;normal=0.;balance=0.;residual=0.;inv={c:0. for c in species};logs={c:[] for c in species};feed={x['component']:float(x['z']) for x in phase_map[0]}
    assert abs(sum(feed.values())-1)<1e-12
    for phase,xx in phase_map.items():
     assert len(xx)==size and {x['component'] for x in xx}==species;beta=float(xx[0]['beta']);beta_sum+=beta;normal=max(normal,abs(sum(float(x['x']) for x in xx)-1))
     assert 0<=beta<=1
     for x in xx:
      c=x['component'];z=float(x['z']);v=float(x['x']);lp=float(x['logphi']);assert all(math.isfinite(y) for y in (z,v,lp,beta)) and z==feed[c] and 0<v<=1 and float(x['beta'])==beta
      inv[c]+=beta*v;logs[c].append(math.log(v)+lp);vectors[(int(row['round']),phase,c)]=(x['type'],beta,z,v,lp)
    normal=max(normal,abs(beta_sum-1));balance=max(abs(inv[c]-feed[c]) for c in species);residual=max(max(v)-min(v) for v in logs.values())
    assert balance<=1e-10 and normal<=1e-12 and residual<=1e-8
    for key,val in [('balance',balance),('normalization',normal),('log_fugacity',residual)]:
     maxima[key]=max(maxima[key],val);assert abs(float(row[key])-val)<1e-13
   if reference is None:reference=vectors
   else:
    assert reference.keys()==vectors.keys()
    for key,v in vectors.items():
     assert v[0]==reference[key][0]
     maxima['matched_state_absolute_difference']=max(maxima['matched_state_absolute_difference'],max(abs(a-b) for a,b in zip(v[1:],reference[key][1:])))
   entries[name]={'ns_per_call':statistics.median(float(x['elapsed_ns'])/int(x['operations']) for x in rows),'bytes_per_call':statistics.median((float(x['allocated_bytes'])/int(x['operations']) if float(x['allocated_bytes'])>=0 else -1) for x in rows),'topologies':sorted(set(x['topology'] for x in rows)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
assert maxima['matched_state_absolute_difference']<=1e-12
assert len(list(raw.glob('*.csv')))==192
comparisons=[]
for profile,rule,scenario,size in cells:
 ratios=[];controls=[];candidate_controls=[];allocations=[]
 for f in range(2):
  names=[f'p{profile}-r{rule}-{scenario}-n{size}-f{f}-{a}' for a in ('base','candidate','control')];b,c,k=[entries[n] for n in names];ratios.append(c['ns_per_call']/b['ns_per_call']);controls.append(k['ns_per_call']/b['ns_per_call']);candidate_controls.append(c['ns_per_call']/k['ns_per_call']);allocations.append({a:entries[n]['bytes_per_call'] for a,n in zip(('base','candidate','control'),names)})
 comparisons.append({'profile':profile,'rule':rule,'scenario':scenario,'components':size,'candidate_over_base_by_fork':ratios,'identical_control_over_base_by_fork':controls,'candidate_over_identical_control_by_fork':candidate_controls,'allocations_by_fork':allocations})
model_cost=[]
for profile in (0,1):
 for scenario,size in [('init1',5),('init3',5),('flash',5),('flash',15)]:
  rr=[]
  for f in range(2):rr.append(entries[f'p{profile}-r4-{scenario}-n{size}-f{f}-candidate']['ns_per_call']/entries[f'p{profile}-r2-{scenario}-n{size}-f{f}-candidate']['ns_per_call'])
  model_cost.append({'profile':profile,'scenario':scenario,'components':size,'rule4_over_rule2_by_fork':rr})
out={'JVMs':96,'rounds':960,'state_rows':vector_rows,'maxima':maxima,'same_rule_comparison':comparisons,'different_thermodynamics_cost':model_cost,'process_medians':entries,'interpretation':'Two independent forks with reversed arm order and an identical-baseline control; descriptive ranges, no statistical non-inferiority or speedup claim. Rule4/rule2 differ in thermodynamics/solver work. Enhanced cold topology cases excluded from overhead comparison.'}
(root/'performance-summary.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:out[k] for k in ('JVMs','rounds','state_rows','maxima')},indent=2))
