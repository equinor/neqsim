"""Frozen unchanged-harness 96-JVM default-path non-regression matrix; run exclusively."""
from pathlib import Path
import subprocess,csv,json,time,fcntl,hashlib,statistics,sys,os
R=Path(__file__).resolve().parent;root=R/'full';out=R/'performance';out.mkdir(exist_ok=True)
cp=(R/'direct-classpath17.txt').read_text();java='/workspace/scratch/4f3e5989087f/toolchains/jdk-17.0.21+9/bin/java'
lock=(R/'native-measurements.lease').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
cells=[(profile,rule,scenario,size) for profile in [0,1] for rule in [2,4] for size in [5,15] for scenario in ['init1','init3','flash'] if size==5 or scenario=='flash']
plan=[]
for cell in cells:
 for fork in range(2):
  for arm in (['base','candidate','control'] if fork==0 else ['control','candidate','base']):plan.append((cell,fork,arm))
assert len(plan)==96
(R/'performance-plan.json').write_text(json.dumps({'base':'611f315adca3a5ac7647ea0105aac6dfe207c7d7','cells':cells,'JVMs':len(plan),'harness':'unchanged HuronVidalSelectedPairPerformanceBenchmark','flags':['-Xms512m','-Xmx512m','-Xbatch','-XX:CICompilerCount=2','-XX:ActiveProcessorCount=2'],'scope':'Default stability behavior only; flag-sensitive new correct topology changes solver work and is not a code-overhead comparison. Existing profiles retain declared alpha/EOS inputs; all nonselected pairs remainClassic.','order':'Reversed arm order in second independent fork. Identical-baseline control. Timings/allocations do not establish absolute optimality.'},indent=2)+'\n')
completed=[]
for idx,(cell,fork,arm) in enumerate(plan):
 profile,rule,scenario,size=cell;name=f'p{profile}-r{rule}-{scenario}-n{size}-f{fork}-{arm}';dest=out/(name+'.csv')
 if dest.exists():raise RuntimeError('Do not overwrite earlier measurement: '+str(dest))
 selected_cp=(str(R/'baseline-prefix')+':' if arm!='candidate' else '')+cp
 cmd=[java,'-Xms512m','-Xmx512m','-Xbatch','-XX:CICompilerCount=2','-XX:ActiveProcessorCount=2','-cp',selected_cp,'neqsim.thermo.mixingrule.HuronVidalSelectedPairPerformanceBenchmark',str(profile),str(rule),scenario,str(dest),str(size)]
 t=time.time()
 with (out/(name+'.log')).open('w') as log:rc=subprocess.call(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,pass_fds=(lock.fileno(),),timeout=600)
 if rc:raise RuntimeError(f'{name} exit {rc}; retain, do not retry')
 rows=list(csv.DictReader(dest.open()));assert len(rows)==10
 for row in rows:
  assert float(row['balance'])<=1e-10 and float(row['normalization'])<=1e-12 and float(row['log_fugacity'])<=1e-8
 completed.append({'name':name,'elapsed_s':time.time()-t,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'rows':len(rows)})
 temp=R/'performance-checkpoint.next.json';temp.write_text(json.dumps(completed,indent=2)+'\n');temp.replace(R/'performance-checkpoint.json')
 print(f'{idx+1}/96 {name}',flush=True)
(R/'performance-complete.json').write_text(json.dumps({'JVMs':len(completed),'rounds':len(completed)*10},indent=2)+'\n')
