import java.io.PrintWriter;
import neqsim.thermo.component.ComponentGENRTLmodifiedHV;
import neqsim.thermo.phase.PhaseGENRTLmodifiedHV;
import neqsim.thermo.phase.PhaseInterface;
import neqsim.thermo.phase.PhaseType;
import neqsim.thermo.system.SystemInterface;
import neqsim.thermo.system.SystemPrEos;
public final class ConstructorProbe {
  public static void main(String[] args) throws Exception {
    SystemInterface fluid = new SystemPrEos(350.0, 10.0);
    fluid.addComponent("water", 0.3); fluid.addComponent("methane", 0.7);
    fluid.setMixingRule(2); fluid.setForceSinglePhase(PhaseType.GAS); fluid.init(3);
    PhaseInterface phase = fluid.getPhase(0);
    double[][] alpha = {{0.0, 0.15}, {0.15, 0.0}};
    double[][] energies = {{0.0, -1500.0}, {4050.0, 0.0}};
    double[][] offsets = {{0.0, 11.0}, {-5.2, 0.0}};
    double[][] kij = {{0.0, 0.03}, {0.03, 0.0}};
    String[][] rules = {{"Classic", "HV"}, {"HV", "Classic"}};
    PhaseGENRTLmodifiedHV ge = new PhaseGENRTLmodifiedHV(phase, alpha, energies, offsets, rules, kij);
    double expected = 0.0;
    for (int i=0;i<2;i++) {
      expected += phase.getComponent(i).getx()*Math.log(((ComponentGENRTLmodifiedHV)ge.getComponent(i)).getGamma(
        phase,2,350.0,10.0,PhaseType.GAS,alpha,energies,offsets,kij,rules));
    }
    expected *= neqsim.thermo.ThermodynamicConstantsInterface.R*phase.getTemperature()*phase.getNumberOfMolesInPhase();
    double before = ge.getExcessGibbsEnergy(phase,2,350.0,10.0,PhaseType.GAS);
    ge.setParams(phase,alpha,energies,offsets,rules,kij);
    double after = ge.getExcessGibbsEnergy(phase,2,350.0,10.0,PhaseType.GAS);
    try (PrintWriter out = new PrintWriter(args[0])) {
      out.println("expected_J,before_explicit_configuration_J,after_explicit_configuration_J");
      out.printf(java.util.Locale.ROOT,"%.17g,%.17g,%.17g%n",expected,before,after);
    }
  }
}
