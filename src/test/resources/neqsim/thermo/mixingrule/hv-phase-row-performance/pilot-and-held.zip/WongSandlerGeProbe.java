import java.io.PrintWriter;
import neqsim.thermo.component.ComponentGEInterface;
import neqsim.thermo.phase.PhaseInterface;
import neqsim.thermo.phase.PhaseType;
import neqsim.thermo.mixingrule.EosMixingRulesInterface;
import neqsim.thermo.system.SystemInterface;
import neqsim.thermo.system.SystemPrEos;
import neqsim.thermo.system.SystemSrkEos;
public final class WongSandlerGeProbe {
  public static void main(String[] args) throws Exception {
    try(PrintWriter out = new PrintWriter(args[0])) {
      out.println("EOS,T_K,component,GE_J,lnGamma,dlnT,dlnTT,dlnN0,dlnN1");
      for(boolean pr:new boolean[]{false,true}) {
        SystemInterface f=pr?new SystemPrEos(350,10):new SystemSrkEos(350,10);
        f.addComponent("water",.3);f.addComponent("methane",.7);f.setMixingRule(2);
        f.setForceSinglePhase(PhaseType.GAS);f.init(3);
        SystemInterface owner=pr?new SystemPrEos(350,10):new SystemSrkEos(350,10);
        owner.addComponent("water",.3);owner.addComponent("methane",.7);owner.setMixingRule(5);
        PhaseInterface ge=((EosMixingRulesInterface)owner.getPhase(0).getMixingRule()).getGEPhase();
        for(double t:new double[]{350,350.25,350}) {
          f.setTemperature(t);f.init(3);PhaseInterface phase=f.getPhase(0);
          double energy=((neqsim.thermo.phase.PhaseGENRTLmodifiedHV) ge).getExcessGibbsEnergy(phase,2,t,10,PhaseType.GAS);
          for(int i=0;i<2;i++) {
            ComponentGEInterface c=(ComponentGEInterface)ge.getComponent(i);
            double[] v={energy,Math.log(c.getGamma()),c.getLnGammadt(),c.getLnGammadtdt(),c.getLnGammadn(0),c.getLnGammadn(1)};
            out.printf(java.util.Locale.ROOT,"%s,%.17g,%d",pr?"PR":"SRK",t,i);
            for(double x:v) { if(!Double.isFinite(x))throw new IllegalStateException("Nonfinite GE output");out.print(","+Double.toHexString(x)); }
            out.println();
          }
        }
      }
    }
  }
}
