import java.io.PrintWriter;
import neqsim.thermo.component.ComponentGEInterface;
import neqsim.thermo.phase.PhaseInterface;
import neqsim.thermo.phase.PhaseType;
import neqsim.thermo.system.SystemInterface;
import neqsim.thermo.system.SystemPrEos;
import neqsim.thermo.system.SystemSrkEos;
public final class WongSandlerProbe {
  public static void main(String[] args) throws Exception {
    try (PrintWriter out = new PrintWriter(args[0])) {
      out.println("EOS,rule,T_K,component,lnPhi,lnGamma,dlnT,dlnTT,dlnN0,dlnN1");
      for(boolean pr : new boolean[]{false,true}) for(int rule : new int[]{5,6}) {
        SystemInterface f = pr ? new SystemPrEos(350,10):new SystemSrkEos(350,10);
        f.addComponent("water",.3); f.addComponent("methane",.7); f.setMixingRule(rule);
        f.setForceSinglePhase(PhaseType.GAS);
        for(double t : new double[]{350,350.25,350}) {
          f.setTemperature(t); f.init(3); PhaseInterface p=f.getPhase(0);
          for(int i=0;i<2;i++) {
            ComponentGEInterface c=(ComponentGEInterface)((neqsim.thermo.mixingrule.EosMixingRulesInterface) p.getMixingRule()).getGEPhase().getComponent(i);
            double[] v={p.getComponent(i).getLogFugacityCoefficient(),Math.log(c.getGamma()),c.getLnGammadt(),
                c.getLnGammadtdt(),c.getLnGammadn(0),c.getLnGammadn(1)};
            out.printf(java.util.Locale.ROOT,"%s,%d,%.17g,%d",pr?"PR":"SRK",rule,t,i);
            for(double x:v) { if(!Double.isFinite(x)) throw new IllegalStateException("Nonfinite"); out.print(","+Double.toHexString(x)); }
            out.println();
          }
        }
      }
    }
  }
}
